 # Whole Donuts Universe public system

`https://wenevergonnaclose.com/` is the single public entry for Whole Donuts
Universe. This document is the source-of-truth map for what the public site
offers, what it does not offer, and how a maintainer may consider new public
material.

## Public paths

| Path | Available now | Boundary |
|---|---|---|
| Community start-here | Yes. The Table, The Counter, Whole Donuts path, and The Nurtured Chef path are public and optional. | No account, profile, enrollment, or personal-data requirement. |
| 28-figure +U gateway | Optional. The first screen offers direct Learn (course), Create (World), and Explore (Library) links. Expand “Choose a stick figure instead” to choose one original visual figure from a broad Youth or Adult group, then choose a bounded need. The page offers a present on-site route: course, World, or Library. A visible Skip to the full site control immediately reaches The Table and reveals its progressive content. | Both choices are temporary page state only: never stored, submitted, tracked, or used as a profile. The figures are visual choices, not a face image, exact age, or identity record. |
| +U Library and free course | Yes. The tracked templates may be copied and adapted for personal use, and the self-directed +U course provides print-ready worksheets. | It creates no account, response record, submission, certification, or public contribution. Do not add private, sensitive, or third-party material without permission. |
| +U World | Yes. The visual studio is an optional public exploration path. | It does not create an account or collect a contribution. |
| Ecosystem map | Yes. It explains the canonical entry, available on-site paths, and intended future domain roles. | Planned domains remain non-clickable until a human verifies destination, ownership, rights, privacy, safety, accessibility, and a return path. |
| Launch Center | Live at `launch.html`: The Nurturer Movement profile, $2,500 goal, ten launch actions, standalone donor-page download, and locally generated support QR. | Cash App and manual Chime to $wholedonuts only. X opens prefilled; Facebook and LinkedIn open share windows with copyable text; emails open the mail client. No automatic sending, account creation, payment processing, recipient records, or funds-raised claims. |
| Donuts New School and Ambassador direction | Yes. They are open learning and leadership directions. | They are not enrollment, certification, employment, an application, or a guaranteed opportunity. |
| Reviewed crumb process | Preparation only. The protocol and template are public. | The static site has no submission runtime; publication is always human-reviewed. |
| Browser-only review queue | Yes. It renders curated metadata already shipped with the site. | It cannot scan, ingest, publish, merge, or access repositories or networks. |
| Goods Window | Browse-only future concepts. | No store, order, payment, or external storefront route is active. |
| Whole Donuts and TNC stores | Future owner-verified routes only. | They are non-clickable placeholders until availability, ownership, content, privacy, and safety are verified. |
| Optional support | A deliberate external Cash App exit or manual Chime instruction is available after confirmation. | It is separate from merchandise and never creates an entitlement, reward, or public record. |

## Privacy and safety boundary

Gateway and World selections exist only in temporary page memory and clear on
reset, skip, routing onward, or reload. The public bundle must not collect or
request names, email addresses, face images, photos, exact age or birth date,
location, sensitive data, repository source contents, secrets, or operational
configuration. The gateway's face choices are accessible text equivalents for
simple visual marks, not image capture or facial data.

Do not add analytics, tracking, accounts, profiling, network scanning,
automatic content intake, automatic publication, automatic GitHub actions, or
automatic merges. The QR generator is bundled locally; it does not contact an external QR service. Do not introduce unreviewed external assets or dependencies. A future
capability is not public until it is explicitly implemented, reviewed, and
truthfully labeled.

Future ecosystem and store domains are not public destinations unless an owner
verifies their availability, ownership, content, privacy, and safety. Until
then, any reference is a non-clickable future owner-verified route, never a
redirect or commerce claim.

The non-deployed [Social Media Protocol](config/social-media-protocol.md)
defines the human-only launch gate and approved, factual course announcement
copy. The owner-authorized Launch Center additionally offers platform share URLs and prepared voluntary-support messages using the shared payment configuration. The protocol does
not authorize account creation, publishing, analytics, tracking, or importing
platform data into this repository.

## Companion repository reconciliation

Universe is the only canonical public bundle and
`wenevergonnaclose.com` is its only canonical public entry. This
reconciliation records source boundaries without importing companion source
contents or representing internal material as live:

| Companion scope | Reconciliation decision | Owner action before any future public use |
|---|---|---|
| `wholedonuts-sunshine` public repository | Metadata and provenance only. Its repository has no detected license or documented reuse grant, so its text, code, imagery, configuration, Pages fallback, and templates are not copied or treated as canonical. | Confirm the original source and explicit reuse scope, then approve a separately reviewed derivative if appropriate. |
| `WHNutz` | Excluded pending rights, privacy, safety, and provenance review. Canonical templates that happen to match are already shipped from Universe; differing source bundles, creative assets, funnel, authentication, and operations material are not migrated. | Record a written rights and safety decision for any proposed sanitized derivative. |
| `wholedonuts-merch-platform` | Excluded from the public bundle. No verified public HTTPS storefront is configured; dashboard, catalog, order, provider, API, deployment, and asset surfaces are not public routes. | Verify a live destination, ownership, rights, privacy, operational readiness, and truthful consumer terms before considering a clearly labeled link. |

The public site may cite the [Sunshine repository](https://github.com/thewholedonuts-beep/wholedonuts-sunshine)
only as an attributable source reference. It must keep the canonical site and
same-site routes as the visitor destination, never an older companion Pages
deployment. This does not imply that every internal asset or capability is
available to the public.

## Human-reviewed source curation

Community learning material may come only from explicitly submitted original
work or permitted public contributions. A contribution must be voluntary and
sent through an owner-approved reviewed channel; the public static site is not
that channel.

Before a maintainer adds material to a public page, template, or queue, they
must:

1. Confirm the item is original or has explicit, adequate permission for the
   intended public reuse.
2. Record a minimal source reference, provenance, rights status, review status,
   attribution requirement, and the manual next step.
3. Review privacy, safety, accuracy for the stated use, accessibility, and
   usefulness. Remove or decline material that includes private, sensitive,
   operational, deceptive, harmful, or unclear-rights content.
4. Keep Sunshine templates and protocol references metadata-only with `needs
   owner review` until explicit reuse rights are documented.
5. Keep WHNutz material, merch material, operational documents, repository
   contents, secrets, and configuration out of public-source candidates unless
   a separate explicit rights and safety decision makes a sanitized derivative
   eligible.
6. Make the proposed change locally, complete human repository review, and
   merge only after approval. Publication requires a separate manual Pages
   dispatch by a maintainer.

The review queue is a shortlist for this process, not a feed. It must never
discover sources, read a repository, scan a network, create a submission,
change a source, publish material, or merge a change automatically.

## Maintainer release checklist

For an eligible public addition, update the relevant public page or template,
`review-queue-manifest.js` when appropriate, this system map when availability
changes, and the release notes. Verify the Pages artifact stages only intended
public files and preserves `CNAME` exactly as `wenevergonnaclose.com`. Dispatch
the deployment manually only after the reviewed merge is present on `main`.
