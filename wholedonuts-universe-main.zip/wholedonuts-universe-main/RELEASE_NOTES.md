 ## Direct entry and current launch documentation

The homepage now opens with Learn, Create, and Explore. The existing 28-figure journey remains optional in an expandable section. Existing TNC/AWD routes, support gates, and privacy boundaries are preserved. The public system map now documents the live Launch Center and its Cash App/Chime-only sharing and download behavior. No registration, tracking, store, DNS, or database changes.

# Whole Donuts Universe release notes

Use this format for each meaningful public update. Keep the first visit simple:
publish only what is available, link to the relevant guide, and leave every
suggestion optional.

## Unreleased

### Whole Donuts entry

**What changed:** The public entry now starts with 28 original visual-only
stick figures: 14 broad Youth figures and 14 broad Adult figures. A visitor
chooses one visual starting point and one bounded need, then receives a direct
route to the live course, World, or +U Library.

**Why it matters:** Visitors get a personal-feeling, legible starting point
without an account, exact age, demographic profile, persistent choices, or an
unverified external destination.

**Optional next choices:** Open a guide, explore the World, visit a community
path, or return later. No action is required.

### Privacy and route corrections

**What changed:** The site no longer creates a persistent +U return pass or
visit record. The optional World uses only temporary page-memory visual
settings, includes a reset control, and returns to The Table through the
canonical same-site route. Gateway destination messages now remain visible
after routing.

**Why it matters:** No public interaction creates a visitor identifier,
profile, stored free-text response, or hidden routing dead end.

**Optional next choices:** Use the gateway, explore the World, reset its
temporary settings, or follow any present on-site path.

### Unblocked entry

**What changed:** The gateway's Skip to the full site control is now always
visible, keyboard-accessible, and immediately reveals and reaches The Table's
full public content.

**Why it matters:** The canonical stick-figure gateway remains the first screen
without blocking direct access to the site.

### Ecosystem direction map

**What changed:** The public site now includes an ecosystem map that explains
the canonical gateway, The Table, The Counter, guides, and World alongside the
intended roles for future domains.

**Why it matters:** Visitors can understand the wider direction without being
sent to an unverified domain or told that a planned store, account, record, or
service is live.

**Optional next choices:** Use any available on-site path. Future domains
become links only after owner verification and human privacy, safety, rights,
accessibility, and destination review.

### Free +U course

**What changed:** The +U Library now opens a free, self-directed course with
print-ready next-step, share-a-crumb, and build-your-table worksheets.

**Why it matters:** Visitors can take an actionable next step with the existing
public template language without opening an account, entering a store, sharing
a response, or providing data to the site.

**Optional next choices:** Print one worksheet or the complete course, use an
editable source template, explore the World, or return to The Table.

### Manual social launch readiness

**What changed:** The canonical course URL includes factual social-preview
metadata, and the Social Media Protocol now supplies a human-only launch gate
and approved text-only course announcement.

**Why it matters:** A responsible account owner can publish the live course
link without connecting an account to the site, adding a tracker, or implying
that a store, submission channel, reward, or companion capability is active.

### Pages delivery

**What changed:** The Pages workflow deploys the reviewed static bundle only
after a maintainer manually dispatches it, retaining
`wenevergonnaclose.com` in the deployed `CNAME`.

**Why it matters:** The public site has one deployable source of truth.

**Optional next choices:** A maintainer can dispatch and review the workflow
run after a human-reviewed merge. Visitors do not need to do anything.

### Operations reliability

**What changed:** Funnel creation now validates a parsed domain before use, and
network activation or deactivation logs an individual funnel failure while
continuing the remaining funnels.

**Why it matters:** A malformed domain cannot cause a runtime index failure,
and one unavailable funnel does not stop the rest of a network operation.

**Optional next choices:** Operators can correct the reported funnel and rerun
the intended operation.
