 # Future comfort-wear concept catalog

This is an internal, non-deployed description catalog. It does not create a
product listing, vendor connection, checkout, price, fulfillment promise, or
customer-data flow. The Pages workflow does not publish `config/`.

## Source-backed browse-only concepts

The following exact concepts were introduced in the accessible WHNutz source at
commit `8ccbce1628655ebe919ecda99a613a40a92010c4` in `index.html`, and were
merged through WHNutz pull request 5. They belong to the shared **Made by +U,
4 ALL** Goods Window. They are concepts, not products for sale.

| Concept | Exact recovered description | Mark | Status |
|---|---|---|---|
| Everyday Tee | Soft, simple, and ready for the long way home. | `+U` | Browse-only concept; awaiting approved artwork. |
| Table Tote | For groceries, books, tools, and whatever helps the next person. | `4 ALL` | Browse-only concept; awaiting approved artwork. |
| Counter Mug | A steady reminder to make room, take a breath, and begin again. | `+U` | Browse-only concept; awaiting approved artwork. |
| Open Water Poster | A calm wall piece for the places where fresh starts happen. | `4 ALL` | Browse-only concept; awaiting approved artwork. |

The same source called these "Printful made-to-order," but it included no
Printful template, product identifier, design file, price, or fulfillment
configuration. That provider reference is historical context, not approval to
connect or activate a vendor.

## Future concepts awaiting approved artwork

Each entry below is only a neutral design direction for ordinary comfort wear
or the existing utility concepts. It is not a claim that artwork, a product,
material, size, stock, safety property, provider capability, price, or delivery
path exists.

| Future concept | Approved expression or visual direction | Status |
|---|---|---|
| Comfort tee | An approved `+U` mark or Made by +U, 4 ALL expression. | Future concept; not for sale; awaiting approved artwork. |
| Crewneck | An approved Made by +U, 4 ALL expression placed after review. | Future concept; not for sale; awaiting approved artwork. |
| Hoodie | An approved anonymous-figure or `+U` mark direction. | Future concept; not for sale; awaiting approved artwork. |
| +U Neck Line | A `+U` neckline or neck-placement expression for a future comfort-wear piece, such as a tee, crewneck, or hoodie. Final garment type, artwork, print or embroidery method, placement, sizing, materials, pricing, vendor, and fulfillment await human-approved designs and print proof. | New planned concept; not for sale; awaiting approved artwork. |
| Jogger or lounge layer | An approved hands-and-jacks mark or neutral approved placement direction. | Future concept; not for sale; awaiting approved artwork. |
| Tote | An approved `+U` or Made by +U, 4 ALL placement direction. | Future concept; not for sale; awaiting approved artwork. |
| Mug | An approved `+U` or anonymous-figure placement direction. | Future concept; not for sale; awaiting approved artwork. |
| Poster | An approved hands-and-jacks or anonymous-figure visual direction. | Future concept; not for sale; awaiting approved artwork. |

**+U Neck Line** is owner-directed new planning language, not a recovered
original product. It means a future `+U` neckline or neck-placement expression,
not a necklace or neckwear item. It follows the same intake, rights, brand
approval, placement, and human print-proof workflow as every other future
concept.

## Required evidence before any public claim or activation

Before an entry can be described as print-ready, displayed as available, or
connected to any provider, a responsible human must approve the source asset,
rights and brand use, product/placement fit, a human print proof, and the
separate provider and customer-support decision. Record that evidence in the
[print-asset intake manifest](print-asset-intake-manifest.md).
Any future price or purchase-promotion decision must also meet the separate
[commerce and promotion readiness policy](commerce-promotion-readiness.md).
Candidate vendor, affiliate, and sponsorship relationships require the separate
[vendor, affiliate, and sponsorship evaluation policy](vendor-affiliate-sponsorship-evaluation.md).

Any future provider checkout must collect only the order data it requires under
that provider's terms. The +U ecosystem site must not collect customer details,
upload customer data, or retain order exports. Cash App and Chime remain
optional support routes only; neither is merchandise payment, checkout, or
fulfillment.
