 const figureField = document.getElementById("figureField");
const customFigure = document.getElementById("customFigure");
const enterButton = document.getElementById("enterButton");
const progressText = document.getElementById("progressText");
const unlockState = document.getElementById("unlockState");
const customizer = document.getElementById("customizer");
const poseSelect = document.getElementById("poseSelect");
const accentInput = document.getElementById("accentInput");
const resetButton = document.getElementById("resetButton");
const pageShell = document.querySelector(".page-shell");
const supportButtons = [...document.querySelectorAll("[data-support-symbol]")];
const supportSymbolStatus = document.getElementById("supportSymbolStatus");

const defaultState = { completed: false, pose: "open", accent: "#ffb95e", supportSymbol: null };
let state = { ...defaultState };
const fieldFigures = [
  { x: 6, y: 50, scale: 1, tilt: "-4deg", pose: "open" },
  { x: 14, y: 26, scale: 0.88, tilt: "2deg", pose: "signal" },
  { x: 20, y: 58, scale: 1.06, tilt: "-1deg", pose: "stride" },
  { x: 29, y: 35, scale: 0.92, tilt: "5deg", pose: "open" },
  { x: 35, y: 61, scale: 1.12, tilt: "-5deg", pose: "signal" },
  { x: 44, y: 22, scale: 0.8, tilt: "3deg", pose: "stride" },
  { x: 50, y: 48, scale: 1, tilt: "-2deg", pose: "open" },
  { x: 57, y: 66, scale: 1.16, tilt: "4deg", pose: "stride" },
  { x: 64, y: 31, scale: 0.86, tilt: "-3deg", pose: "signal" },
  { x: 70, y: 53, scale: 1.02, tilt: "2deg", pose: "open" },
  { x: 77, y: 18, scale: 0.74, tilt: "-6deg", pose: "stride" },
  { x: 83, y: 58, scale: 1.08, tilt: "3deg", pose: "signal" },
  { x: 90, y: 39, scale: 0.94, tilt: "-4deg", pose: "open" }
];

const poseMap = {
  open: {
    leftArm: [27, 48, 13, 61],
    rightArm: [27, 48, 41, 61],
    leftLeg: [27, 74, 18, 98],
    rightLeg: [27, 74, 36, 98]
  },
  stride: {
    leftArm: [27, 48, 14, 53],
    rightArm: [27, 48, 39, 66],
    leftLeg: [27, 74, 14, 98],
    rightLeg: [27, 74, 38, 90]
  },
  signal: {
    leftArm: [27, 48, 17, 28],
    rightArm: [27, 48, 41, 61],
    leftLeg: [27, 74, 19, 99],
    rightLeg: [27, 74, 35, 97]
  }
};

function createStickFigure(pose, accent) {
  const shape = poseMap[pose] || poseMap.open;
  const wrapper = document.createElement("div");
  wrapper.className = accent ? "stick-figure special" : "stick-figure";
  if (accent) {
    wrapper.style.setProperty("--accent", accent);
  }

  wrapper.innerHTML = `
    <svg viewBox="0 0 54 110" role="presentation" focusable="false">
      <circle cx="27" cy="18" r="10"></circle>
      <line x1="27" y1="28" x2="27" y2="74"></line>
      <line x1="${shape.leftArm[0]}" y1="${shape.leftArm[1]}" x2="${shape.leftArm[2]}" y2="${shape.leftArm[3]}"></line>
      <line x1="${shape.rightArm[0]}" y1="${shape.rightArm[1]}" x2="${shape.rightArm[2]}" y2="${shape.rightArm[3]}"></line>
      <line x1="${shape.leftLeg[0]}" y1="${shape.leftLeg[1]}" x2="${shape.leftLeg[2]}" y2="${shape.leftLeg[3]}"></line>
      <line x1="${shape.rightLeg[0]}" y1="${shape.rightLeg[1]}" x2="${shape.rightLeg[2]}" y2="${shape.rightLeg[3]}"></line>
    </svg>
  `;

  return wrapper;
}

function renderField() {
  figureField.innerHTML = "";
  fieldFigures.forEach((figure, index) => {
    const element = createStickFigure(figure.pose);
    element.style.left = `${figure.x}%`;
    element.style.top = `${figure.y}%`;
    element.style.setProperty("--x", "-50%");
    element.style.setProperty("--y", "-50%");
    element.style.setProperty("--scale", figure.scale);
    element.style.setProperty("--tilt", figure.tilt);
    element.style.setProperty("--delay", `${index * 0.22}s`);
    figureField.appendChild(element);
  });
}

function renderCustomFigure(state) {
  customFigure.innerHTML = "";
  customFigure.style.setProperty("--accent", state.accent);
  const figure = createStickFigure(state.pose, state.accent);
  figure.style.position = "static";
  figure.style.width = "96px";
  figure.style.height = "136px";
  figure.style.transform = "scale(1.15)";
  customFigure.appendChild(figure.firstElementChild);
  if (state.supportSymbol) {
    const source = supportButtons.find((button) => button.dataset.supportSymbol === state.supportSymbol);
    const symbol = source?.querySelector("svg")?.cloneNode(true);
    if (symbol) {
      symbol.removeAttribute("role");
      symbol.removeAttribute("aria-label");
      symbol.setAttribute("aria-hidden", "true");
      symbol.classList.add("selected-support-symbol");
      customFigure.appendChild(symbol);
    }
  }
}

function applyState() {
  poseSelect.value = state.pose;
  accentInput.value = state.accent;
  poseSelect.disabled = !state.completed;
  accentInput.disabled = !state.completed;
  supportButtons.forEach((button) => {
    const selected = button.dataset.supportSymbol === state.supportSymbol;
    button.disabled = !state.completed;
    button.setAttribute("aria-pressed", String(selected));
  });
  supportSymbolStatus.textContent = state.supportSymbol
    ? "Your original support symbol is part of this temporary figure."
    : "No support symbol selected.";
  progressText.textContent = state.completed
    ? "The field is open. Your visual choices stay on this page until you reset or reload."
    : "The field is ready to explore.";
  unlockState.classList.toggle("locked", !state.completed);
  pageShell.classList.toggle("completed", state.completed);
  renderCustomFigure(state);
}

function completeJourney() {
  state.completed = true;
  applyState();
}

enterButton.addEventListener("click", completeJourney);
customizer.addEventListener("input", () => {
  state.pose = poseSelect.value;
  state.accent = accentInput.value;
  applyState();
});
supportButtons.forEach((button) => {
  button.addEventListener("click", () => {
    if (!state.completed) return;
    state.supportSymbol = state.supportSymbol === button.dataset.supportSymbol
      ? null
      : button.dataset.supportSymbol;
    applyState();
  });
});
resetButton.addEventListener("click", () => {
  state = { ...defaultState };
  applyState();
});

renderField();
applyState();
