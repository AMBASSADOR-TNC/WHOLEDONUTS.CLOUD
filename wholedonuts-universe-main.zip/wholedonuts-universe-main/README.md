 # Whole Donuts Universe

## Launch Center

`launch.html` adds ten owner-operated launch actions to the existing +U entry.
The shared `launch-config.js` supplies the owner-confirmed Cash App route and
manual ChimeSign, both for **$wholedonuts**. These are the only supported payment
providers. There is no automatic payment processor. No browser-local override or
URL parameter can replace the recipient, and no new account details are needed.

The Launch Center prepares X, Facebook, LinkedIn, native sharing with copy
fallback, a pre-surgery request, an outreach email, a standalone donor page, and
a locally generated support QR. X opens prefilled; Facebook and LinkedIn open
the ecosystem link and require pasting the provided message. Email actions open
the user's mail app. Nothing posts or sends automatically. Chime always requires
manual entry in its official app. The QR library is qrcode-generator 1.4.4 by
Kazuhiko Arase, distributed under the MIT license with its header preserved.

The existing public support consent gate and sensitive-campaign separation are
preserved. TNC/AWD return paths remain available; no unverified store is promoted
as live. Inactive operations examples reference the shared config and do not
enable automated payment gateways.

Validate with `node --test tests/campaign-protocol.test.js tests/launch-center.test.js`.
After merging, run the existing **Deploy public Pages site** workflow. It stages
the launch files and QR library alongside the existing allowlisted public bundle.
The canonical route is `https://wenevergonnaclose.com/launch.html` after deployment.

This repository is the consolidated home for the Whole Donuts Universe.

## Public site

The repository root contains the static GitHub Pages bundle for
`wenevergonnaclose.com`:

The public movement statement invites every visitor to "find a piece of peace"
and try a new direction when part of life feels restrained. It is welcoming
language, not a promise of treatment, recovery, or a guaranteed outcome.

- `index.html`, `guide.html`, `ecosystem.html`, `course.html`, `course.js`, `PUBLIC_SYSTEM.md`, `styles.css`, and `app.js`
  provide the one public Whole Donuts entry, system map, curation policy, and
  +U experience. The free course includes print-ready worksheets that use only
  the existing public template language and text marks; it does not collect
  responses. The ecosystem map distinguishes the available canonical on-site
  routes from planned domains that require owner verification.
- The public +U Library includes a Movement Launch Brief for schools, companies,
  boards, teams, community groups, and personal projects. It requires independent
  authority verification before organizational affiliation is claimed and
  separates youth safety, remembrance, sports marks, voluntary support, commerce,
  rewards, and campaign expiration.
- `CNAME` declares `wenevergonnaclose.com` as the custom domain.
- `pro/` is the canonical Whole Donuts Professional workspace. It gives
  authorized organizations a clear path from the public gateway to the Movement
  Launch Brief, authority verification, rights review, approved distribution,
  and campaign closeout. The `wholedonuts.pro` domain currently uses an obsolete,
  insecure forward. Its registrar must update that forward to an HTTPS 301 redirect
  into the canonical gateway at
  `https://wenevergonnaclose.com/?u=professional`; see
  `config/wholedonuts-pro-routing.md`.
  Prior purchases or voluntary support never create partnership authority.
  A single verified voluntary-support payment of $250 or more enters a private
  contributor-impact reporting path. Public recognition requires separate explicit
  consent. This remains manual until verified payment events, secure contact
  handling, and consent records are connected to production infrastructure.
- The +U gateway starts with direct Learn, Create, and Explore links to the free
  course, World, and Library. No account or figure choice is required. An optional
  expandable journey preserves 28 original visual stick figures: 14 broad Youth
  figures and 14 broad Adult figures. One visual choice and one of three bounded
  non-sensitive needs lead to a present on-site course, World, or Library route.
  Both temporary choices clear on restart, skip, back, or onward navigation and
  are never sent, tracked, or stored. The gateway never asks for an exact age
  or birth date, name, email, face image, photo, location, account, or sensitive
  information.
- The optional +U World keeps visual pose and color choices only in page
  memory. Its support-symbol gallery adds four original, non-official choices
  for public safety, fire and rescue, civic unity, and military families and
  veterans. No symbol copies an agency badge, seal, uniform mark, government
  emblem, or military-branch insignia; the gallery disclaims affiliation and
  merchandise rights. All visual choices clear on reset or reload and are never
  sent, tracked, or stored.
- The browser-only +U review queue renders the small, curated
  `review-queue-manifest.js` list already shipped with the site. It has no
  filesystem access, GitHub API access, network scanning, automatic
  publishing, or automatic merging. Every candidate is review-only and shows
  its source reference, category, provenance, rights status, review status,
  and manual next step. The queue also documents excluded sources and why they
  are not eligible.

### Refreshing the review queue

Maintainers refresh the queue through the normal local/repository workflow:

1. Review a public, tracked source manually and edit
   `review-queue-manifest.js` locally.
2. Keep each candidate's `title`, `source`, `category` (`draft`, `image`, or
   `crumb`), `provenance`, `rights`, `reviewStatus`, and `nextStep` accurate
   and specific. Record uncertain or ineligible sources in
   `WHNUTZ_REVIEW_QUEUE_EXCLUSIONS` with a clear reason.
3. Review and merge the manifest change normally. A human must complete every
   stated next step; the site never discovers candidates, changes sources,
   publishes material, or merges work automatically.

  The public site creates no visitor identifier, return pass, profile, or
  visit record. Daily SEO and learning targets remain outside the public site
  in access-controlled operations and require explicit human activation and
  release review.

  The public SEO Crumb Saver treats deliberate public pages, guides, templates,
  and canonical invitations as discovery entry points for reviewed knowledge. It
  does not collect a visitor profile or submit material from this static site.
  The root uses canonical, robots, sitemap, social-preview, and factual WebSite
  metadata. The non-deployed [SEO Crumb Saver operating model](config/seo-crumb-saver-operating-model.md)
  requires human review of aggregate visibility and prohibits tracking, scraping,
  credentials, rank manipulation, and automatic publishing.

  The public `+U/u` invitation protocol accepts only exact, reviewed campaign
  tokens from `campaign-protocol.js`. Temporary tokens change contextual copy and
  one suggested on-site route; they never create tracking, registration, referral
  acceptance, affiliation, payment, or reward proof. The first campaign group
  expires automatically at `2026-09-06T14:11:44Z`. The learning and remembrance
  group expires at `2026-09-11T14:34:45Z`. Remembrance routes are deliberately
  separated from merchandise, support payments, and rewards. `FDNY` is used only
  as a factual remembrance context and does not imply affiliation, endorsement,
  trademark permission, or merchandise rights.

  The non-deployed [Social Media Protocol](config/social-media-protocol.md)
  provides the manual launch gate and factual course announcement copy. It uses
  direct canonical links only and prohibits account connections, auto-posting,
  tracking links, platform-data intake, and unreviewed media reuse.

The [`deploy-pages` workflow](.github/workflows/deploy-pages.yml) publishes
the reviewed public bundle only when a maintainer dispatches it manually. It
stages only named public static files, including the exact
`CNAME`, and excludes Go operations configuration and local credentials. In
**Settings -> Pages**, select **GitHub Actions** as the source and set the
custom domain to `wenevergonnaclose.com`; GitHub provides the required DNS and
verification instructions. The workflow verifies the deployed revision through
the GitHub Pages URL, so custom-domain DNS propagation does not make a valid
deployment look failed. Any future domain or DNS change requires a separate
reviewed operational change.

### Public system and curation policy

[`PUBLIC_SYSTEM.md`](PUBLIC_SYSTEM.md) is the public system map and maintainer
curation policy. It identifies available local public paths, unavailable areas,
external exits, the privacy boundary, and the human-only process for considering
eligible original or permitted public material. It does not authorize
collection, automated intake, publication, GitHub actions, or merges.

### Companion repository reconciliation

Universe is the single canonical public bundle. The Sunshine repository is
recorded only as a public source/provenance reference pending an owner-confirmed
reuse grant; its code, text, imagery, configuration, and legacy Pages fallback
are not imported or linked as a canonical destination. WHNutz and the merch
platform remain separate: their differing source material, operational
configuration, authentication, and commerce surfaces require explicit rights,
privacy, safety, and owner review before any future sanitized derivative can be
considered. No companion repository implies that an internal asset, storefront,
submission channel, or service is live.

## Operations tooling

The Go 1.21 funnel and domain operations project remains in `cmd/`, `pkg/`,
`config/`, `workflows/`, and `projects/`. It is separate from the static Pages
site. See [SETUP.md](SETUP.md) and [README_FUNNELS.md](README_FUNNELS.md) for
operational setup; keep credentials in local environment files or GitHub
Actions secrets, never in the repository.

## Voluntary Support Access and Rewards Center

The public voluntary-support hub is an interface and policy, not a payment
processor, wallet, fund-transfer system, automatic billing system, or
automatic allocation system. A visitor must select a voluntary support purpose,
review the processor and payee, and affirm a final action before an external
payment link is revealed. Store purchases remain separate merchant
transactions, not donations. The Share & Invitation Protocol creates a
non-sensitive ecosystem link only when a visitor explicitly shares or copies
it; it does not track recipients or create referral, payment, or reward records.
Cash App and Chime to `$wholedonuts` are the only allowed manual provider
routes. Cash App is the consent-gated optional external exit. Chime has no
universal public payment URL, so the same gate reveals only an instruction to
open the official Chime app, enter the ChimeSign, and optionally copy it;
copying never initiates a payment or transfer. No other provider is part of
this model.

Whole Donuts is an LLC, not a nonprofit. Public copy describes payments as
voluntary support to Whole Donuts LLC, not as charitable donations, and no
charitable tax receipt is provided. Support is not a purchase, investment, or
automatic reward credit.
The experience also recognizes time, skill, encouragement, sharing, trying, and
showing up as useful crumbs without ranking anyone's worth by financial amount.

Real accounting, charity or tax treatment, refunds, merchant-of-record
responsibilities, and reward eligibility require decisions by the responsible
entity and configured providers. See the non-deployed
[Donation Access Hub operating model](config/donation-access-operating-model.md)
for operational constraints.

The public Crumb Saver protocol and contribution template remain available, but
the current static Pages configuration contains no approved submission runtime.
Its form is visibly unavailable and accepts no text, so it cannot discard a
submission. Do not link a separate Crumb Saver endpoint unless its owner
supplies and verifies it.

## Consolidation and learning

Universe is the verified system of record for material that has completed
intake; it does not claim that all legacy or private material has migrated.
The non-deployed [consolidation and learning model](config/consolidation-learning-model.md)
defines classification, preserve-before-remove provenance, reviewed learning
loops, and staged legacy retirement. It prohibits automatic publishing,
deletion, payment, credential import, and private-data import.
